import {StatusBar} from 'react-native';

export const StatusHeight = StatusBar.currentHeight;
