export class UserDto {
    id: number;
    name: string;
    phone_number: string;
    school_id: number;
    email: string;
    password: number;
    coins: number;
}
