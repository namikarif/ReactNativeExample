export class BaseDto {
    id: number;
}
