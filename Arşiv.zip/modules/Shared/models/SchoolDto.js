import {BaseDto} from "./BaseDto";

export class SchoolDto extends BaseDto {
    name: string;
    members: number;
}
