declare module '*.png';
